package com.example.sebatapp;

public class EditData {
}
