package com.example.sebatapp.Util;

public class ServerAPI {
    private final static String BASE_URL = "http://192.168.1.67/sebat/Pinjam";
    public static final String URL_DATA   = BASE_URL + "/Api";
    public static final String URL_INSERT = BASE_URL + "/ApiInsert";
    public static final String URL_DELETE = BASE_URL + "/ApiDelete";
    public static final String URL_UPDATE = BASE_URL + "/ApiUpdate";
    public static final String URL_LOGIN = BASE_URL + "/ApiLogin";
}